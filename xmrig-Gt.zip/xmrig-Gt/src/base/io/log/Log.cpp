/* XMRig
 * Copyright (c) 2019      Spudz76     <https://github.com/Spudz76>
 * Copyright (c) 2018-2021 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2021 XMRig       <https://github.com/xmrig>, <support@xmrig.com>
 *
 * This program is free software under GNU GPL v3 or later.
 */

#ifdef WIN32
#   include <winsock2.h>
#   include <windows.h>
#endif

#include <algorithm>
#include <cassert>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include <uv.h>
#include <vector>
#include <cstdarg>
#include <cstdio>

#include "base/io/log/Log.h"
#include "base/kernel/interfaces/ILogBackend.h"
#include "base/tools/Chrono.h"
#include "base/tools/Object.h"

namespace xmrig {

static const char *colors_map[] = {
    RED_BOLD_S,    // EMERG
    RED_BOLD_S,    // ALERT
    RED_BOLD_S,    // CRIT
    RED_S,         // ERR
    YELLOW_S,      // WARNING
    WHITE_BOLD_S,  // NOTICE
    nullptr,       // INFO
#   ifdef WIN32
    BLACK_BOLD_S   // DEBUG
#   else
    BRIGHT_BLACK_S // DEBUG
#   endif
};

class LogPrivate
{
public:
    XMRIG_DISABLE_COPY_MOVE(LogPrivate)

    LogPrivate() = default;
    ~LogPrivate() { for (auto backend : m_backends) delete backend; }
    void add(ILogBackend *backend) { m_backends.push_back(backend); }

    void print(Log::Level level, const char *fmt, va_list args)
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (Log::isBackground() && m_backends.empty()) return;

        char buffer[Log::kMaxBufferSize]{};
        vsnprintf(buffer, sizeof(buffer), fmt, args);
        std::string msg(buffer);

        const char* emoji = "";
        const char* color = "";
        switch(level){
            case Log::EMERG:
            case Log::ALERT:
            case Log::CRIT:   emoji="💥"; color=RED_BOLD_S; break;
            case Log::ERR:     emoji="❌"; color=RED_S; break;
            case Log::WARNING: emoji="⚠️"; color=YELLOW_S; break;
            case Log::NOTICE:  emoji="ℹ️"; color=WHITE_BOLD_S; break;
            case Log::DEBUG:   emoji="🐞"; color=BRIGHT_BLACK_S; break;
            case Log::INFO:    emoji="💡"; color=nullptr; break;
            default:           emoji="";   color=nullptr; break;
        }

        std::string out;
        out += color ? color : "";
        out += "[" + std::string(emoji) + "] ";
        out += msg;
        out += CLEAR "\n";

        fputs(out.c_str(), stdout);
        fflush(stdout);

        if(!m_backends.empty()){
            uint64_t ts = 0;
            for(auto backend : m_backends){
                backend->print(ts, level, buffer, 0, strlen(buffer), false);
            }
        }
    }

private:
    char m_buf[Log::kMaxBufferSize]{};
    std::mutex m_mutex;
    std::vector<ILogBackend*> m_backends;
};

bool Log::m_background = false;
bool Log::m_colors     = true;
LogPrivate* Log::d     = nullptr;
uint32_t Log::m_verbose = 0;

} // namespace xmrig

void xmrig::Log::add(ILogBackend *backend){ if(d) d->add(backend); }
void xmrig::Log::destroy(){ delete d; d=nullptr; }
void xmrig::Log::init(){ d=new LogPrivate(); }

void xmrig::Log::print(const char *fmt,...){
    if(!d) return;
    va_list args; va_start(args,fmt);
    d->print(NONE,fmt,args);
    va_end(args);
}

void xmrig::Log::print(Level level,const char *fmt,...){
    if(!d) return;
    va_list args; va_start(args,fmt);
    d->print(level,fmt,args);
    va_end(args);
}